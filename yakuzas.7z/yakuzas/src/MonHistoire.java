
public class MonHistoire {	
	
	public static void main(String[] Args){
		
		/*
		Commercant C1 = new Commercant("Marchand", 100);
		Yakuza Y1 = new Yakuza("Yaku", 1000, "ramen", "HP");
		Ronin R1 = new Ronin("Roro", 200, "Oasis");
		Samourai S1 = new Samourai("Samou", 150, "eau", "Sir Rouanet");
		
		Y1.extorquer(C1);
		Y1.solde();
		C1.solde();		
		
		Y1.getReputation();
		
		
		R1.setHonneur(50);
		Y1.setReputation(20);
		System.out.println(R1.getHonneur() + "reputation : "+ Y1.getReputation());
		R1.provoquer(Y1);
		
		Y1.direBonjour();
		
		S1.direBonjour();
		S1.boire("Milkshake");*/
		
		// Une belle histoire :
		/*Humain h = new Humain("Prof", 10, "Portos");
		h.direBonjour();
		h.boire();
		
		Commercant c = new Commercant("Marchand", 35);
		c.direBonjour();
		
		Yakuza y = new Yakuza("Yaku_le_noir", 42, "biere", "WarSong");
		y.extorquer(c);
		
		Ronin r = new Ronin("Roro", 61, "sake");
		r.donner(c, 10);
		r.provoquer(y);
		r.direBonjour();
		*/
		Commercant C1 = new Commercant("Marchand", 100);
		Traitre T = new Traitre("Remi", 100000, "Fiiz", "Pascal");
		T.direBonjour();
		T.extorquer(C1);
		T.faireLeGentil(C1, 20);
		
		GrandMere GM = new GrandMere("Grand m�re Feuillage");
		GM.faireConnaissanceAvec(C1);
		GM.faireConnaissanceAvec(T);
		GM.ragoter();
		
	}
}
