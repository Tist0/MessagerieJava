
public class Humain {

	private String nom;
	private int argent;
	public String boisson;
	
	// Constructeur	
	public Humain(String nom, int argent, String boisson) {
		this.nom = nom;
		this.argent = argent;
		this.boisson = boisson;
	}
	
	
	public void parler(String texte){
		System.out.println(nom +" - "+texte);
	}

	public void direBonjour(){
		this.parler("Bonjour! Je m'appelle "+nom+" et j'aime boire du "+boisson);
	}

	public void boire(){
		this.parler("Ahhh, un bon verre de "+boisson+"! GLOUPS!");
	}

	public void solde(){
		this.parler("Je suis riche! Je poss�de "+ argent + " pi�ces d'or.");
	}



	//Getters	 
	public String getNom() {
		return nom;
	}
	public int getArgent() {
		return argent;
	}	
	public String getBoisson() {
		return boisson;
	}
	
	//Modifier l'argent
	public void gagner(int argent) {
		this.argent += argent;
	}
	
	public void perdre(int argent) {
		this.argent -= argent;
	}


	/**
	 * @param boisson the boisson to set
	 */
	public void setBoisson(String boisson) {
		this.boisson = boisson;
	}
	
	
	
	
}
