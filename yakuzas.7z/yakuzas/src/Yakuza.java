
public class Yakuza extends Humain {

	private int reputation;
	private String clan;
	
	// Constructeur
	public Yakuza(String nom, int argent, String boisson, String clan) {
				
		super(nom, argent, boisson);
		this.reputation = 0;
		this.clan = clan;	
	}
	

	public void extorquer(Commercant c){
		int argent;
		argent = c.seFaireExtorquer();
		this.gagner(argent);
		this.parler("Hahaha je t'ai extorqu�!");
		this.reputation++;
	}
	
	public void gagnerDuel() {
		this.reputation++;
		this.parler("Je suis toujours le vainqueur!");
	}
	
	public int perdreDuel() {
		this.reputation--;
		this.parler("NOOOOOOOONN je suis mauvais perdant :(");
		return(this.getArgent());
	}
	
	public void direBonjour() {		
		super.direBonjour();
		parler("J'appartiens au clan "+ this.clan );
	}
	

	
	// Accesseurs
	public int getReputation() {
		return reputation;
	}
	public void setReputation(int reputation) {
		this.reputation = reputation;
	}
	public String getClan() {
		return clan;
	}
	public void setClan(String clan) {
		this.clan = clan;
	}	

}
