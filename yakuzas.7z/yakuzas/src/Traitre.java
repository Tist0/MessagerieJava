
public class Traitre extends Samourai{

	private int niveauTraitrise;
	
	public Traitre(String nom, int argent, String boisson, String seigneur) {
		super(nom, argent, boisson, seigneur);
		this.niveauTraitrise = 0;
	}
	
	public void faireLeGentil(Humain h, int don) {
		if(don<= getArgent()){					
			h.gagner(don);
			perdre(don);
			parler("Accepte ce don de "+don+" pi�ces mon ami!");
			if((don/10) > niveauTraitrise)
				niveauTraitrise -= (don/10);
			else
				niveauTraitrise = 0;
		}
		else
			parler("J'annule mon don, je l'ai pas assez d'argent");
	}
	
	public void extorquer(Commercant c){
		if(niveauTraitrise <=3){
			niveauTraitrise ++;
		}
		gagner(c.seFaireExtorquer());
	}
	public void direBonjour() {
		super.direBonjour();
		parler("Cours! Mon niveau de traitrise est de " + niveauTraitrise);
	}
}
