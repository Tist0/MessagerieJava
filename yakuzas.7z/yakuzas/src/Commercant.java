
public class Commercant extends Humain{

	// Constructeur
	public Commercant(String nom, int argent) {		
		super(nom, argent, "the");
	}
	
	public int seFaireExtorquer() {
		int somme = super.getArgent();
		this.perdre(somme);
		this.parler("J'ai tout perdu T_T");
		return somme;
	}
	
	public void recevoir(int a) {
		this.parler("Merci pour ce don mon ami, reviens quand tu veux! ");
		this.gagner(a);
	}
	
}
