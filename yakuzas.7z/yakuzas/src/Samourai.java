
public class Samourai extends Ronin{

	private String seigneur;
	
	public Samourai(String nom, int argent, String boisson, String seigneur) {
		super(nom, argent, boisson);
		this.seigneur = seigneur;
	}
	
	public void direBonjour() {
		super.direBonjour();
		this.parler("Je suis au service de " + seigneur);
	}
	
	public void boire(String boisson) {
		this.setBoisson(boisson);
		super.boire();
	}

}
