public class Ronin extends Humain {

	private int honneur;
	
	public Ronin(String nom, int argent, String boisson) {
		super(nom, argent, boisson);
		this.honneur = 1;
	}
	public void donner(Commercant c, int montant) {
		c.recevoir(montant);
		this.perdre(montant);
	}
	
	public void provoquer(Yakuza y) {
		if ((this.honneur *2) > y.getReputation()){
			int argent = 0;
			this.honneur++;
			this.gagner(y.perdreDuel());
			y.perdre(argent);
			this.parler("J'ai gagn� le duel.");			
		}
		else{
			this.honneur--;
			y.gagnerDuel();
			this.parler("J'ai perdu le duel.");
		}
	}
	
	
	// Accesseurs
	public int getHonneur() {
		return honneur;
	}
	public void setHonneur(int honneur) {
		this.honneur = honneur;
	}
}
