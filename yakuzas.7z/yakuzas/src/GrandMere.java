import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;


public class GrandMere extends Humain {

	public GrandMere(String nom) {
		super(nom, 0, "tisane");		
	}
	
	private ArrayList<Humain> memoire = new ArrayList<Humain>();
	
	private String humainHasard() {
		String personne;
		Random nbrRand = new Random();
		
		int i = nbrRand.nextInt(5);
		
		switch(i){
		case 1:
			personne = "Commercant";
			break;		
		
		case 2:
			personne = "Yakuza";
			break;		
		
		case 3:
			personne = "Ronin";
			break;		
		
		case 4:
			personne = "Samourai";
			break;		
				
		default :
			personne = "Humain";
		}		
		return personne;
	}
	
	public void faireConnaissanceAvec(Humain h) {
		memoire.add(h);
	}
	
	public void ragoter(){
		Iterator<Humain> it = memoire.iterator();
		Humain stock;
		
		while(it.hasNext()){
			stock = it.next();
			if(stock instanceof Traitre)
				parler("Brulez "+stock.getNom()+", c'est un traitre");
			else 
				parler("Ma voisine m'a dit que "+stock.getNom()+" est un "+ humainHasard());
		}
	}

	
}
